                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3460629
Laser cut Steins Gate Dice Tower by RilleSelene is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Laser cut Steins;gate dice tower with detachable tray.  This was made on 1/8" thick boards.  It will fit on a single 12" x 24" board.  The size fully assembled is 4" tall by 3.5" wide.  The dice tray that is added to the tower is 3" x 3".  

# Post-Printing

## Assembly

Please see photo instructions (PDF) for assembly.  Or here:
https://docs.google.com/presentation/d/1IMJmZ6EJTedKqTYkhHZWpNsdHXPSuwSBIy6Lfm30cZI/edit?usp=sharing
I stained it before assembly.  
The order the numbered pieces are in is important since they aren't all cut the same. 
The detachable dice tray that stores inside can be put together with rubber bands or a strip of leather or other material with holes in it.
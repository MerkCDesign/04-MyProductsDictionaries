                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3254790
Marque Place Noël - Christmas Place Holder by Baroudeur is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

FR
Une simple petite boite au couvercle souple, faite dans du contreplaqué de 3mm pour marquer la place sur votre table de Noël. Vous pouvez la peindre, ou pas, et y mettre dedans 2 ou 3 chocolats. Dimensions 5x5x5 cm.

Gravure et découpe avec une laser CO2 50W en utilisant le logiciel Lightburn (https://lightburnsoftware.com/) qui permet à la fois de graver, d'imprimer des photos et de découper, le tout, très facilement. La boite se construit aisément et ne nécessite pas de colle.

Il est possible d'éditer les textes (polices de caractères incluses dans les fichiers). Une plaque de fond vierge vous permet de mettre votre propre signature.

Joyeux Noël !!!

ENG
A simple small box with a soft lid, made in 3mm plywood to mark the place on your Christmas table. You can paint it or not, and put in 2 or 3 chocolates. Dimensions 5x5x5 cm.

Engraving and cutting with a 50W CO2 laser using Lightburn software (https://lightburnsoftware.com/) that allows you to engrave, print photos and cut, all very easily. The box is easily built and does not require glue.

It is possible to edit the texts (fonts included in the files). A blank background plate allows you to put your own signature.

Merry Christmas !!!

# Print Settings

Printer: Laser CO2 50W
Rafts: Doesn't Matter
Supports: Doesn't Matter
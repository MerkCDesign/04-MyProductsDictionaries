                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3257429
Lasercut wooden LED christmas scene triangle by sylviev is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

Lasercut Christmas scene with LED lights in triangle shape.
There's 2 files: 
Christmas triangle and Christmas reindeer. 

- Christmas triangle: front and back plate. Front with forest scene and back with stars. Two sides and 2 smaller rectangles for the bottom. 
- Christmas reindeer: shape of reindeer to put behind the front plate. 

- Assemble the back, with 2 sides and bottoms. Leave a space in the middle at the bottom for the battery box of your LED lights.
I bought a small string of 10 LED lights which are a bit diffused. 
Measure your LED battery box. Maybe you'll have to make the sides bigger or smaller and change the bottoms to the size of your battery box. 
You can use wood glue or a hot glue gun to assemble the pieces. 

- Next, you can glue the LED lights in place. Make sure the they are evenly spread out on the back plate. 

- Assemble the front. Glue the reindeer piece to the back of of the front plate. I painted the reindeer piece white to make it stand out more. 
I also cut a triangle shape out of some frosted plastic from a folder. Glue the plastic to the back of the front plate. (I used double sided tape for this).

- Glue the front plate to the triangle. That's it

I would love to see your makes!